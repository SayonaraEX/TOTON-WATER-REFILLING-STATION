import tkinter as tk
from tkinter import messagebox, ttk

# Login Page
class LoginApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("TONTON WATER REFILLING STATION")
        self.geometry("700x400")
 # Set background color to a light blue
        self.configure(bg='#e0f7fa')

        self.create_widgets()

    def create_widgets(self):
# Frame for the title
        title_frame = tk.Frame(self, bg='#e0f7fa')
        title_frame.pack(pady=25)

        self.label1 = tk.Label(title_frame, text="TONTON WATER REFILLING STATION", font=("Times New Roman", 26, "bold"), bg="#E0F7FA", fg="#01579B")
        self.label1.pack()

# Frame for the login form
        form_frame = tk.Frame(self, bg='#e0f7fa')
        form_frame.pack(pady=60)

        self.label2 = tk.Label(form_frame, text="Username:", font=("Tahoma", 13), bg="#E0F7FA", fg="#01579B")
        self.label2.grid(row=0, column=0, pady=5, padx=10)
        self.username = tk.Entry(form_frame, width=30)
        self.username.grid(row=0, column=1, pady=5, padx=10)

        self.label3 = tk.Label(form_frame, text="Password:", font=("Tahoma", 13), bg="#E0F7FA", fg="#01579B")
        self.label3.grid(row=1, column=0, pady=5, padx=10)
        self.password = tk.Entry(form_frame, show='*', width=30)
        self.password.grid(row=1, column=1, pady=5, padx=10)

        self.login_button = tk.Button(form_frame, text="LOG IN", bg="#00796b", fg="white", font=("Tahoma", 13, "bold"), command=self.login)
        self.login_button.grid(row=2, columnspan=2, pady=20)


    def login(self):
        user = self.username.get()
        passw = self.password.get()

# If input box not filled
        if not user or not passw:
            messagebox.showwarning("Input Error", "Please enter username and password.")
            return

# Check the username and password from the datasheet.txt file
        if self.verify_login(user, passw):
            messagebox.showinfo("Success", "Login Successful!")
            self.destroy()
# Successful  login page pop
            ManagementPage().mainloop()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password.")

    def verify_login(self, username, password):
        try:
            with open("datasheet.txt", "r") as file:
                for line in file:
                    file_username, file_password = line.strip().split(",")
                    if file_username == username and file_password == password:
                        return True
        except FileNotFoundError:
            messagebox.showerror("File Error", "datasheet.txt file not found.")
        except Exception as e:
            messagebox.showerror("File Error", f"An error occurred: {e}")
        return False

# Management Page
class ManagementPage(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("MANAGEMENT PAGE")
        self.geometry("1400x770")
        self.configure(bg="#E0F7FA")
        self.create_widgets()

 # Create a label for the management page
    def create_widgets(self):
        # Header
        self.header_frame = tk.Frame(self, bg="#0288D1", height=50)
        self.header_frame.pack(fill=tk.X)

        self.header_label = tk.Label(self.header_frame, text="ADMINISTRATOR PAGE OF TONTON WATER REFILLING STATION", font=("Times New Roman", 23), bg="#0288D1", fg="white")
        self.header_label.pack(pady=10)

# Create tabs using ttk.Notebook
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(expand=1, fill="both")

# Frames for different tabs
        self.customer_tab = tk.Frame(self.tabs, bg="#E0F7FA")
        self.order_tab = tk.Frame(self.tabs, bg="#E0F7FA")
        self.inventory_tab = tk.Frame(self.tabs, bg="#E0F7FA")
        self.report_tab = tk.Frame(self.tabs, bg="#E0F7FA")
        self.logout_tab = tk.Frame(self.tabs, bg="#E0F7FA")

# Different tabs or feature in "MANAGEMENT PAGE"
        self.tabs.add(self.customer_tab, text="Customer Management")
        self.tabs.add(self.order_tab, text="Order Management")
        self.tabs.add(self.inventory_tab, text="Inventory Management")
        self.tabs.add(self.report_tab, text="Sales Reports")
        self.tabs.add(self.logout_tab, text="Log Out")

# We use TNotebook.tab
# Set padding and font for the tab labels.
# Change the background color of selected tabs to blue.
        self.style = ttk.Style()
        self.style.configure('TNotebook.Tab', padding=(77, 7), font=('Arial', 11), foreground="#01579B")
        self.style.map('TNotebook.Tab')

# Create tabs for customer, order, inventory, and report sections.
        self.create_customer_tab()
        self.create_order_tab()
        self.create_inventory_tab()
        self.create_report_tab()
        self.create_logout_tab()

# Customer tab/feature
    def create_customer_tab(self):
        label = tk.Label(self.customer_tab, text="Customer Management", font=("Times New Roman", 20), bg="#E0F7FA", fg="#01579B")
        label.pack(pady=20)

# Create a customer management interface
        self.customer_tree = ttk.Treeview(self.customer_tab, columns=("ID", "Name", "Address", "Phone"),
                                          show="headings")
        self.customer_tree.heading("ID", text="Customer ID")
        self.customer_tree.heading("Name", text="Name")
        self.customer_tree.heading("Address", text="Address")
        self.customer_tree.heading("Phone", text="Phone")
        self.customer_tree.pack(pady=20)

# Create input fields for customer information
        form_frame = tk.Frame(self.customer_tab, bg="#E0F7FA")
        form_frame.pack(pady=10)

        tk.Label(form_frame, text="Customer ID:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=0, column=0, padx=5, pady=5)
        self.customer_id_entry = tk.Entry(form_frame)
        self.customer_id_entry.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(form_frame, text="Name:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=1, column=0, padx=5, pady=5)
        self.customer_name_entry = tk.Entry(form_frame)
        self.customer_name_entry.grid(row=1, column=1, padx=5, pady=5)

        tk.Label(form_frame, text="Address:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=2, column=0, padx=5, pady=5)
        self.customer_address_entry = tk.Entry(form_frame)
        self.customer_address_entry.grid(row=2, column=1, padx=5, pady=5)

        tk.Label(form_frame, text="Phone:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=3, column=0, padx=5, pady=5)
        self.customer_phone_entry = tk.Entry(form_frame)
        self.customer_phone_entry.grid(row=3, column=1, padx=5, pady=5)

# Create button
        button_frame = tk.Frame(self.customer_tab, bg="#E0F7FA")
        button_frame.pack(pady=10)

# Different buttons in Customer Management Page
        tk.Button(button_frame, text="Add Customer", bg="white", fg="#01579B", command=self.add_customer).grid(row=0, column=0, padx=5, pady=5)
        tk.Button(button_frame, text="Edit Customer", bg="white", fg="#01579B", command=self.edit_customer).grid(row=0, column=1, padx=5, pady=5)
        tk.Button(button_frame, text="Delete Customer", bg="white", fg="#01579B", command=self.delete_customer).grid(row=0, column=2, padx=5,
                                                                                           pady=5)
# Load customer data from a file and populate a treeview widget.
# If the file doesn't exist, create an empty one.
        self.load_customers()
    def load_customers(self):
        for row in self.customer_tree.get_children():
            self.customer_tree.delete(row)

        try:
            with open("customers.txt", "r") as file:
                for line in file:
                    customer = line.strip().split(",")
                    self.customer_tree.insert("", tk.END, values=customer)
        except FileNotFoundError:
            with open("customers.txt", "w") as file:
                pass

    """
    Adds a new customer to the system based on user input.
    Validates input fields and writes customer data to a file.
    """
    def add_customer(self):

        customer_id = self.customer_id_entry.get()
        name = self.customer_name_entry.get()
        address = self.customer_address_entry.get()
        phone = self.customer_phone_entry.get()

        if not customer_id or not name or not address or not phone:
            messagebox.showwarning("Input Error", "Please fill all fields.")
            return

        try:
            with open("customers.txt", "a") as file:
                file.write(f"{customer_id},{name},{address},{phone}\n")
            self.load_customers()
            self.clear_customer_entries()
        except Exception as e:
            messagebox.showerror("File Error", f"An error occurred: {e}")

    """
    Edits an existing customer's information based on user input and using 'customer id'.
    Validates input fields and updates customer data in a file.
    """

    def edit_customer(self):
        selected_item = self.customer_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a customer to edit.")
            return

        customer_id = self.customer_id_entry.get()
        name = self.customer_name_entry.get()
        address = self.customer_address_entry.get()
        phone = self.customer_phone_entry.get()

        if not customer_id or not name or not address or not phone:
            messagebox.showwarning("Input Error", "Please fill all fields.")
            return

        try:
            customers = []
            with open("customers.txt", "r") as file:
                customers = file.readlines()

            with open("customers.txt", "w") as file:
                for customer in customers:
                    if customer.startswith(f"{customer_id},"):
                        file.write(f"{customer_id},{name},{address},{phone}\n")
                    else:
                        file.write(customer)

            self.load_customers()
            self.clear_customer_entries()
        except Exception as e:
            messagebox.showerror("File Error", f"An error occurred: {e}")

    """
    Deletes the selected customer from the system.
    Reads customer data from a file, removes the specified customer, and updates the file.
    """
    def delete_customer(self):
        selected_item = self.customer_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a customer to delete.")
            return

        customer_id = self.customer_tree.item(selected_item[0], "values")[0]

        try:
            customers = []
            with open("customers.txt", "r") as file:
                customers = file.readlines()

            with open("customers.txt", "w") as file:
                for customer in customers:
                    if not customer.startswith(f"{customer_id},"):
                        file.write(customer)

            self.load_customers()
            self.clear_customer_entries()
        except Exception as e:
            messagebox.showerror("File Error", f"An error occurred: {e}")

#Clears the input fields for customer information.
    def clear_customer_entries(self):
        self.customer_id_entry.delete(0, tk.END)
        self.customer_name_entry.delete(0, tk.END)
        self.customer_address_entry.delete(0, tk.END)
        self.customer_phone_entry.delete(0, tk.END)

# Create a label for the order management section
    def create_order_tab(self):
        label = tk.Label(self.order_tab, text="Order Management", font=("Times New Roman", 20), bg="#E0F7FA", fg="#01579B")
        label.pack(pady=20)

# Create a Treeview widget to display order information
        self.order_tree = ttk.Treeview(self.order_tab, columns=("OrderID", "CustomerID", "Quantity", "Date"),
                                       show="headings")
        self.order_tree.heading("OrderID", text="Order ID")
        self.order_tree.heading("CustomerID", text="Customer ID")
        self.order_tree.heading("Quantity", text="Quantity")
        self.order_tree.heading("Date", text="Date")
        self.order_tree.pack(pady=20)

# Create a frame for input fields
        form_frame = tk.Frame(self.order_tab, bg="#E0F7FA")
        form_frame.pack(pady=10)

# Add labels and entry fields for order details
        tk.Label(form_frame, text="Order ID:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=0, column=0, padx=5, pady=5)
        self.order_id_entry = tk.Entry(form_frame)
        self.order_id_entry.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(form_frame, text="Customer ID:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=1, column=0, padx=5, pady=5)
        self.order_customer_id_entry = tk.Entry(form_frame)
        self.order_customer_id_entry.grid(row=1, column=1, padx=5, pady=5)

        tk.Label(form_frame, text="Quantity:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=2, column=0, padx=5, pady=5)
        self.order_quantity_entry = tk.Entry(form_frame)
        self.order_quantity_entry.grid(row=2, column=1, padx=5, pady=5)

        tk.Label(form_frame, text="Date:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=3, column=0, padx=5, pady=5)
        self.order_date_entry = tk.Entry(form_frame)
        self.order_date_entry.grid(row=3, column=1, padx=5, pady=5)

# Create buttons for order management actions
        button_frame = tk.Frame(self.order_tab, bg="#E0F7FA")
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Add Order", bg="white", fg="#01579B", command=self.add_order).grid(row=0, column=0, padx=5, pady=5)
        tk.Button(button_frame, text="Edit Order", bg="white", fg="#01579B", command=self.edit_order).grid(row=0, column=1, padx=5, pady=5)
        tk.Button(button_frame, text="Delete Order", bg="white", fg="#01579B", command=self.delete_order).grid(row=0, column=2, padx=5, pady=5)

        self.load_orders()

# Load order data from a file and populate a treeview widget.
# If the file doesn't exist, create an empty one
    def load_orders(self):
        for row in self.order_tree.get_children():
            self.order_tree.delete(row)

        try:
            with open("orders.txt", "r") as file:
                for line in file:
                    order = line.strip().split(",")
                    self.order_tree.insert("", tk.END, values=order)
        except FileNotFoundError:
            with open("orders.txt", "w") as file:
                pass

    def add_order(self):
# Get input values from the GUI widgets
        order_id = self.order_id_entry.get()
        customer_id = self.order_customer_id_entry.get()
        quantity = self.order_quantity_entry.get()
        date = self.order_date_entry.get()
# Check if any field is empty
        if not order_id or not customer_id or not quantity or not date:
            messagebox.showwarning("Input Error", "Please fill all fields.")
            return

        try:
# LOad the order details to the "orders.txt" file
            with open("orders.txt", "a") as file:
                file.write(f"{order_id},{customer_id},{quantity},{date}\n")
# Reload the orders and clear the input fields
            self.load_orders()
            self.clear_order_entries()
        except Exception as e:
# Show an error message if there's an issue with file handling
            messagebox.showerror("File Error", f"An error occurred: {e}")

    def edit_order(self):
# Get the selected item from the order tree
        selected_item = self.order_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select an order to edit.")
            return
# Get input values for editing
        order_id = self.order_id_entry.get()
        customer_id = self.order_customer_id_entry.get()
        quantity = self.order_quantity_entry.get()
        date = self.order_date_entry.get()

# Check if any field is empty
        if not order_id or not customer_id or not quantity or not date:
            messagebox.showwarning("Input Error", "Please fill all fields.")
            return

        try:
# Read existing orders from the file
            orders = []
            with open("orders.txt", "r") as file:
                orders = file.readlines()

# Update the order details for the specified order ID
            with open("orders.txt", "w") as file:
                for order in orders:
                    if order.startswith(f"{order_id},"):
                        file.write(f"{order_id},{customer_id},{quantity},{date}\n")
                    else:
                        file.write(order)
# Reload the orders and clear the input fields
            self.load_orders()
            self.clear_order_entries()

# Show an error message if there's an issue with file handling
        except Exception as e:
            messagebox.showerror("File Error", f"An error occurred: {e}")

    def delete_order(self):

# Get the selected item from the order tree
        selected_item = self.order_tree.selection()
        if not selected_item:
 # Show a warning if no order is selected for deletion

            messagebox.showwarning("Selection Error", "Please select an order to delete.")
            return

        order_id = self.order_tree.item(selected_item)["values"][0]

        try:
# Read existing orders from the file
            orders = []
            with open("orders.txt", "r") as file:
                orders = file.readlines()

# Write back all orders except the one with the specified order ID
            with open("orders.txt", "w") as file:
                for order in orders:
                    if not order.startswith(f"{order_id},"):
                        file.write(order)

# Reload the orders and clear the input fields
            self.load_orders()
            self.clear_order_entries()
        except Exception as e:

# Show an error message if there's an issue with file handling
            messagebox.showerror("File Error", f"An error occurred: {e}")

    def clear_order_entries(self):
# Clear the input fields for order details
        self.order_id_entry.delete(0, tk.END)
        self.order_customer_id_entry.delete(0, tk.END)
        self.order_quantity_entry.delete(0, tk.END)
        self.order_date_entry.delete(0, tk.END)

    def create_inventory_tab(self):
# Create a label for the order inventory section
        label = tk.Label(self.inventory_tab, text="Inventory Management", font=("Times New Roman", 20), bg="#E0F7FA", fg="#01579B")
        label.pack(pady=20)

# Create a Treeview widget to display order information
        self.inventory_tree = ttk.Treeview(self.inventory_tab, columns=("ItemID", "ItemName", "Quantity", "Threshold"),
                                           show="headings")
        self.inventory_tree.heading("ItemID", text="Item ID")
        self.inventory_tree.heading("ItemName", text="Item Name")
        self.inventory_tree.heading("Quantity", text="Quantity")
        self.inventory_tree.heading("Threshold", text="Threshold")
        self.inventory_tree.pack(pady=20)
# Create a frame for input fields
        form_frame = tk.Frame(self.inventory_tab, bg="#E0F7FA")
        form_frame.pack(pady=10)

# Add labels and entry fields for inventory details
        tk.Label(form_frame, text="Item ID:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=0, column=0, padx=5, pady=5)
        self.inventory_id_entry = tk.Entry(form_frame)
        self.inventory_id_entry.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(form_frame, text="Item Name:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=1, column=0, padx=5, pady=5)
        self.inventory_name_entry = tk.Entry(form_frame)
        self.inventory_name_entry.grid(row=1, column=1, padx=5, pady=5)

        tk.Label(form_frame, text="Quantity:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=2, column=0, padx=5, pady=5)
        self.inventory_quantity_entry = tk.Entry(form_frame)
        self.inventory_quantity_entry.grid(row=2, column=1, padx=5, pady=5)

        tk.Label(form_frame, text="Threshold:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=3, column=0, padx=5, pady=5)
        self.inventory_threshold_entry = tk.Entry(form_frame)
        self.inventory_threshold_entry.grid(row=3, column=1, padx=5, pady=5)

# Create buttons for order management actions
        button_frame = tk.Frame(self.inventory_tab, bg="#E0F7FA")
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Add Item", bg="white", fg="#01579B", command=self.add_inventory).grid(row=0, column=0, padx=5, pady=5)
        tk.Button(button_frame, text="Edit Item", bg="white", fg="#01579B", command=self.edit_inventory).grid(row=0, column=1, padx=5, pady=5)
        tk.Button(button_frame, text="Delete Item", bg="white", fg="#01579B", command=self.delete_inventory).grid(row=0, column=2, padx=5, pady=5)

        self.load_inventory()

# Load inventory data from a file and populate a treeview widget.
# If the file doesn't exist, create an empty one
    def load_inventory(self):
        for row in self.inventory_tree.get_children():
            self.inventory_tree.delete(row)

        try:
            with open("inventory.txt", "r") as file:
                for line in file:
                    item = line.strip().split(",")
                    self.inventory_tree.insert("", tk.END, values=item)
        except FileNotFoundError:
            with open("inventory.txt", "w") as file:
                pass

    def add_inventory(self):
 # Get input values from the GUI widgets
        item_id = self.inventory_id_entry.get()
        item_name = self.inventory_name_entry.get()
        quantity = self.inventory_quantity_entry.get()
        threshold = self.inventory_threshold_entry.get()

# Check if any field is empty
        if not item_id or not item_name or not quantity or not threshold:
            messagebox.showwarning("Input Error", "Please fill all fields.")
            return

        try:
# Inventory details to the "inventory.txt" file
            with open("inventory.txt", "a") as file:
                file.write(f"{item_id},{item_name},{quantity},{threshold}\n")
# Reload the inventory and clear the input fields
            self.load_inventory()
            self.clear_inventory_entries()
        except Exception as e:
# Show an error message if there's an issue with file handling
            messagebox.showerror("File Error", f"An error occurred: {e}")

    def edit_inventory(self):
# Get the selected item from the inventory tree
        selected_item = self.inventory_tree.selection()
        if not selected_item:
# Show a warning if no item is selected for editing
            messagebox.showwarning("Selection Error", "Please select an item to edit.")
            return

# Get input values for editing
        item_id = self.inventory_id_entry.get()
        item_name = self.inventory_name_entry.get()
        quantity = self.inventory_quantity_entry.get()
        threshold = self.inventory_threshold_entry.get()

# Check if any field is empty
        if not item_id or not item_name or not quantity or not threshold:
            messagebox.showwarning("Input Error", "Please fill all fields.")
            return

        try:
# Read existing inventory items from the file
            inventory = []
            with open("inventory.txt", "r") as file:
                inventory = file.readlines()

# Update the inventory details for the specified item ID
            with open("inventory.txt", "w") as file:
                for item in inventory:
                    if item.startswith(f"{item_id},"):
                        file.write(f"{item_id},{item_name},{quantity},{threshold}\n")
                    else:
                        file.write(item)

# Reload the inventory and clear the input fields
            self.load_inventory()
            self.clear_inventory_entries()
        except Exception as e:

# Show an error message if there's an issue with file handling
            messagebox.showerror("File Error", f"An error occurred: {e}")

    def delete_inventory(self):
# Get the selected item from the inventory tree
        selected_item = self.inventory_tree.selection()
        if not selected_item:

# Show a warning if no item is selected for deletion
            messagebox.showwarning("Selection Error", "Please select an item to delete.")
            return
# Extract the item ID from the selected item
        item_id = self.inventory_tree.item(selected_item)["values"][0]

        try:
# Read existing inventory items from the file
            inventory = []
            with open("inventory.txt", "r") as file:
                inventory = file.readlines()
 # Write back all items except the one with the specified item ID
            with open("inventory.txt", "w") as file:
                for item in inventory:
                    if not item.startswith(f"{item_id},"):
                        file.write(item)

# Reload the inventory and clear the input fields
            self.load_inventory()
            self.clear_inventory_entries()
        except Exception as e:
# Show an error message if there's an issue with file handling
            messagebox.showerror("File Error", f"An error occurred: {e}")

    def clear_inventory_entries(self):
# Clear the input fields for item details
        self.inventory_id_entry.delete(0, tk.END)
        self.inventory_name_entry.delete(0, tk.END)
        self.inventory_quantity_entry.delete(0, tk.END)
        self.inventory_threshold_entry.delete(0, tk.END)

# Create a label for the sales report section
    def create_report_tab(self):
        label = tk.Label(self.report_tab, text="Sales Reports", font=("Times New Roman", 20), bg="#E0F7FA", fg="#01579B")
        label.pack(pady=20)

# Create a Treeview widget to display sales report information
        self.report_tree = ttk.Treeview(self.report_tab, columns=("Date", "TotalSales"), show="headings",
                                        selectmode="extended")
        self.report_tree.heading("Date", text="Date")
        self.report_tree.heading("TotalSales", text="Total Sales")
        self.report_tree.pack(pady=20)

# Create a frame for input field
        form_frame = tk.Frame(self.report_tab, bg="#E0F7FA")
        form_frame.pack(pady=10)

# Add labels and entry fields for sales report details
        tk.Label(form_frame, text="Date:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=0, column=0, padx=5, pady=5)
        self.report_date_entry = tk.Entry(form_frame)
        self.report_date_entry.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(form_frame, text="Total Sales:", font=13, bg="#E0F7FA", fg="#01579B").grid(row=1, column=0, padx=5, pady=5)
        self.report_sales_entry = tk.Entry(form_frame)
        self.report_sales_entry.grid(row=1, column=1, padx=5, pady=5)

# Create buttons for sales report actions
        button_frame = tk.Frame(self.report_tab, bg="#E0F7FA")
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Add Report", bg="white", fg="#01579B", command=self.add_report).grid(row=0, column=0, padx=5, pady=5)
        tk.Button(button_frame, text="Edit Report", bg="white", fg="#01579B", command=self.edit_report).grid(row=0, column=1, padx=5, pady=5)
        tk.Button(button_frame, text="Delete Report", bg="white", fg="#01579B", command=self.delete_report).grid(row=0, column=2, padx=5, pady=5)
        tk.Button(button_frame, text="Compute Total Sales", bg="white", fg="#01579B", command=self.compute_total_sales).grid(row=1, column=0,
                                                                                                   columnspan=3, padx=5,
                                                                                                   pady=5)
# Total sales of selected row/s
        self.total_sales_label = tk.Label(self.report_tab, text="Total Sales Amount: $0.00", font=("Arial", 12, "bold"), bg="#E0F7FA", fg="#01579B")
        self.total_sales_label.pack(pady=10)

        self.load_reports()
        self.calculate_total_sales()  # Initial total sales calculation

# Load inventory data from a file and populate a treeview widget.
# If the file doesn't exist, create an empty one
    def load_reports(self):
        for row in self.report_tree.get_children():
            self.report_tree.delete(row)

        try:
            with open("reports.txt", "r") as file:
                for line in file:
                    report = line.strip().split(",")
                    self.report_tree.insert("", tk.END, values=report)
        except FileNotFoundError:
            with open("reports.txt", "w") as file:
                pass

    def add_report(self):
# Get input values from the GUI widgets
        date = self.report_date_entry.get()
        total_sales = self.report_sales_entry.get()

# Check if any field is empty
        if not date or not total_sales:
            messagebox.showwarning("Input Error", "Please fill all fields.")
            return

        try:
# Details to the "reports.txt" file
            with open("reports.txt", "a") as file:
                file.write(f"{date},{total_sales}\n")
# Reload the inventory and clear the input fields
            self.load_reports()
            self.clear_report_entries()
            self.calculate_total_sales()  # Update total sales amount

        except Exception as e:
# Show an error message if there's an issue with file handling
            messagebox.showerror("File Error", f"An error occurred: {e}")

    def edit_report(self):
# Get the selected item from the inventory tree
        selected_items = self.report_tree.selection()
        if not selected_items:
# Show a warning if no item is selected for editing
            messagebox.showwarning("Selection Error", "Please select a report to edit.")
            return

        for item in selected_items:
            date = self.report_tree.item(item)["values"][0]
            total_sales = self.report_sales_entry.get()

            if not date or not total_sales:
                messagebox.showwarning("Input Error", "Please fill all fields.")
                return

            try:
# Read existing reports from the file
                reports = []
                with open("reports.txt", "r") as file:
                    reports = file.readlines()
# Update the report details for the specified date
                with open("reports.txt", "w") as file:
                    for report in reports:
                        if report.startswith(f"{date},"):
                            file.write(f"{date},{total_sales}\n")
                        else:
                            file.write(report)
# Reload the reports and clear the input fields
                self.load_reports()
                self.clear_report_entries()
                self.calculate_total_sales()  # Update total sales amount
            except Exception as e:
# Show an error message if there's an issue with file handling
                messagebox.showerror("File Error", f"An error occurred: {e}")

    def delete_report(self):
# Get the selected item from the report tree
        selected_items = self.report_tree.selection()
        if not selected_items:
# Show a warning if no item is selected for deletion
            messagebox.showwarning("Selection Error", "Please select a report to delete.")
            return

        for item in selected_items:
            date = self.report_tree.item(item)["values"][0]

            try:
# Read existing reports from the file
                reports = []
                with open("reports.txt", "r") as file:
                    reports = file.readlines()

# Write back all reports except the one with the specified date
                with open("reports.txt", "w") as file:
                    for report in reports:
                        if not report.startswith(f"{date},"):
                            file.write(report)
# Reload the reports and clear the input fields
                self.load_reports()
                self.clear_report_entries()
                self.calculate_total_sales()  # Update total sales amount
            except Exception as e:
 # Show an error message if there's an issue with file handling
                messagebox.showerror("File Error", f"An error occurred: {e}")

    def clear_report_entries(self):
# Clear the input fields for report details
        self.report_date_entry.delete(0, tk.END)
        self.report_sales_entry.delete(0, tk.END)

    def calculate_total_sales(self):
# Calculate the total sales amount from the "reports.txt" file
        total_sales = 0.0
        try:
            with open("reports.txt", "r") as file:
                for line in file:
                    report = line.strip().split(",")
                    if len(report) == 2:  # Ensure valid format (Date, TotalSales)
                        total_sales += float(report[1])
        except FileNotFoundError:
            pass  # Handle if file not found

# Update the total sales label
        self.total_sales_label.config(text=f"Total Sales Amount: ₱{total_sales:.2f}")

    def compute_total_sales(self):
# Get the selected items from the report tree
        selected_items = self.report_tree.selection()

# Check if any items are selected
        if not selected_items:
            messagebox.showwarning("Selection Error", "Please select one or more reports to compute total sales.")
            return

# Total sales amount
        total_sales = 0.0
        try:

# Open the "reports.txt" file for reading
            with open("reports.txt", "r") as file:
                for line in file:
# Split the line into report name and sales amount
                    report = line.strip().split(",")
# Check if the report name matches any selected item
                    if len(report) == 2 and report[0] in [self.report_tree.item(item)["values"][0] for item in
                                                          selected_items]:
                        total_sales += float(report[1])
        except FileNotFoundError:
            pass  # Handle if file not found

# Update the label with the total selected sales amount
        self.total_sales_label.config(text=f"Total Selected Sales Amount: ₱{total_sales:.2f}")

# LOG OUT or return to login page
    def create_logout_tab(self):
        label = tk.Label(self.logout_tab, text="Log Out", font=("Times New Roman", 20), bg="#E0F7FA", fg="#01579B")
        label.pack(pady=20)

        logout_button = tk.Button(self.logout_tab, text="Log Out", font=("Times New Roman", 26, "bold"), bg="red", fg="white", command=self.logout, height=4,
                                  width=10)
        logout_button.place(relx=0.5, rely=0.5, anchor="center")

    def logout(self):
        self.destroy()
        LoginApp().mainloop()


if __name__ == "__main__":
    app = LoginApp()
    app.mainloop()
